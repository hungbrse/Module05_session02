import React from "react";
import UserItem from "./UserItem";

export default function UserList() {
  const userList = [
    {
      id: 1,
      name: "hùng đẹp trai",
      age: 18,
      email: "hungdz1002@gmail.com",
      birthDay: "28/12/2001",
      manage: "Modulator",
    },
    {
      id: 2,
      name: "hùng đẹp trai",
      age: 18,
      email: "hungdz1002@gmail.com",
      birthDay: "28/12/2001",
      manage: "Modulator",
    },
    {
      id: 3,
      name: "hùng đẹp trai",
      age: 18,
      email: "hungdz1002@gmail.com",
      birthDay: "28/12/2001",
      manage: "Modulator",
    },
    {
      id: 4,
      name: "hùng đẹp trai",
      age: 18,
      email: "hungdz1002@gmail.com",
      birthDay: "28/12/2001",
      manage: "Modulator",
    },
  ];
  return (
    <>
      {userList.map((u) => (
        <UserItem key={u.id} item={u} />
      ))}
      ;
    </>
  );
}
