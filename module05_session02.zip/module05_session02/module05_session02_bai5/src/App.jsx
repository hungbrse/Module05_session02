import { useState } from "react";
import "./App.css";

function App() {
  const [count, setCount] = useState(0);
  // count[number1, setNumber1] = useState(0);
  const [number1, setNumber1] = useState(0);
  const [number2, setNumber2] = useState(0);
  // count[number2, setNumber2] = useState(0);
  const [sum, setSum] = useState(0);

  const calculateSum = () => {
    setSum(Number(number1) + Number(number2));
  };
  return (
    <>
      <div>
        <h2>tính tổng hai số </h2>
        <input
          type="number"
          name=""
          id=""
          // value={number1}
          value={number1}
          onChange={(e) => setNumber1(e.target.value)}
          placeholder="nhập số thứ nhất"
        />

        <input
          type="number"
          name=""
          id=""
          // value={number2}
          value={number2}
          onChange={(e) => setNumber2(e.target.value)}
          placeholder="nhập số thứ hai"
        />

        <button onClick={calculateSum}>tính tổng</button>
        <h3>kết quả :{sum}</h3>
      </div>
    </>
  );
}

export default App;
