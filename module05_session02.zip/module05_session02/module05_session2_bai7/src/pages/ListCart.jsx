import React from "react";
import CartItem from "./CartItem";

export default function ListCart() {
  const carts = [
    {
      id: 1,
      name: "16 pro max",
      description: "rất đẹp",
      image:
        "https://nanado.edu.vn/uploads/images/blog/admin/2024/02/07/anh-gai-xinh-2k5-2k6-2k7-2k8-cuc-de-thuong-dang-yeu-1707242033.webp",

      quantity: 5,
      price: 100,
    },
    {
      id: 2,
      name: "16 pro max",
      description: "rất đẹp",
      image:
        "https://www.google.com/url?sa=i&url=https%3A%2F%2Fispacedanang.edu.vn%2Fhinh-anh-dep-ve-hoc-sinh-cap-3.html&psig=AOvVaw20tr7XKBK1M0oZ8ajYVAPC&ust=1732265950953000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCIC3ku-H7YkDFQAAAAAdAAAAABAE",

      quantity: 5,
      price: 100,
    },
    {
      id: 3,
      name: "16 pro max",
      description: "rất đẹp",
      image:
        "https://www.google.com/url?sa=i&url=https%3A%2F%2Fispacedanang.edu.vn%2Fhinh-anh-dep-ve-hoc-sinh-cap-3.html&psig=AOvVaw20tr7XKBK1M0oZ8ajYVAPC&ust=1732265950953000&source=images&cd=vfe&opi=89978449&ved=0CBQQjRxqFwoTCIC3ku-H7YkDFQAAAAAdAAAAABAE",

      quantity: 5,
      price: 100,
    },
  ];
  return (
    <>
      {carts.map((item) => (
        <CartItem key={item.id} item={item}></CartItem>
      ))}
    </>
  );
}
