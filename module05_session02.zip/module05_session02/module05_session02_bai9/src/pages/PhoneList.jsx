import React from "react";
import PhoneItem from "./PhoneItem";

export default function PhoneList() {
  const PhoneList = [
    { id: 1, name: "16 pro max", price: 18 },
    { id: 2, name: "16 pro max", price: 18 },
    { id: 3, name: "16 pro max", price: 18 },
    { id: 4, name: "16 pro max", price: 18 },
    { id: 5, name: "16 pro max", price: 18 },
  ];

  return (
    <>
      {PhoneList.map((item, index) => (
        <PhoneItem key={item.id} itemProp={item} indexProp={index + 1} />
      ))}
    </>
  );
}
