import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <h1>Danh Sách Khóa Học</h1>
    <ul>
      <li>HTML</li>
      <li>Javascrip</li>
      <li>Python</li>
      <li>C#</li>
    </ul>
    
    </>
  )
}

export default App
